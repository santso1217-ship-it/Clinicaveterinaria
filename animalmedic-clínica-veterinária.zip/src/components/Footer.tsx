import { CLINIC_INFO } from '../data/clinicData';

export function Footer() {
  return (
    <footer className="border-t border-[hsl(var(--border-subtle))] bg-[hsl(var(--background))] py-12">
      <div className="mx-auto flex max-w-[1200px] flex-col justify-between gap-8 px-4 sm:px-6 lg:flex-row lg:items-center lg:px-8">
        <div>
          <p className="font-display text-lg font-semibold text-[hsl(var(--foreground))]">
            {CLINIC_INFO.brandFull}
          </p>
          <p className="mt-1 text-sm text-[hsl(var(--muted-foreground))]">
            {CLINIC_INFO.address}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-6 text-sm font-semibold text-[hsl(var(--muted-foreground))]">
          <a
            href="#inicio"
            className="transition-colors duration-150 hover:text-[hsl(var(--foreground))]"
          >
            Início
          </a>
          <a
            href="#servicos"
            className="transition-colors duration-150 hover:text-[hsl(var(--foreground))]"
          >
            Serviços
          </a>
          <a
            href="#sobre"
            className="transition-colors duration-150 hover:text-[hsl(var(--foreground))]"
          >
            Sobre
          </a>
          <a
            href="#dicas"
            className="transition-colors duration-150 hover:text-[hsl(var(--foreground))]"
          >
            Dicas
          </a>
          <a
            href="#contato"
            className="transition-colors duration-150 hover:text-[hsl(var(--foreground))]"
          >
            Contato
          </a>
        </div>

        <p className="text-xs text-[hsl(var(--muted-foreground))]">
          © {new Date().getFullYear()} {CLINIC_INFO.brandFull}
        </p>
      </div>
    </footer>
  );
}
