import { useEffect, useState, type FormEvent } from 'react';
import { motion } from 'motion/react';
import {
  AlertTriangle,
  CheckCircle2,
  MapPin,
  MessageCircle,
  Phone,
} from 'lucide-react';
import {
  buildWhatsAppUrl,
  CLINIC_INFO,
  SERVICES,
} from '../data/clinicData';

interface ContactBookingSectionProps {
  preselectedService: string;
}

type PetSpecies = 'Cão' | 'Gato';
type PreferredPeriod = 'Manhã' | 'Tarde' | 'Flexível';

export function ContactBookingSection({
  preselectedService,
}: ContactBookingSectionProps) {
  const [tutorName, setTutorName] = useState('');
  const [petName, setPetName] = useState('');
  const [species, setSpecies] = useState<PetSpecies>('Cão');
  const [service, setService] = useState<string>(SERVICES[3].title);
  const [period, setPeriod] = useState<PreferredPeriod>('Manhã');
  const [notes, setNotes] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [submittedUrl, setSubmittedUrl] = useState('');

  useEffect(() => {
    if (preselectedService) {
      setService(preselectedService);
      setSubmittedUrl('');
    }
  }, [preselectedService]);

  const emergencyHref = buildWhatsAppUrl(
    'EMERGÊNCIA: Olá, preciso de orientação veterinária imediata para meu pet.'
  );

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const cleanTutor = tutorName.trim();
    const cleanPet = petName.trim();

    if (cleanTutor.length < 2) {
      setErrorMessage('Informe seu nome para continuarmos o agendamento.');
      return;
    }
    if (cleanPet.length < 1) {
      setErrorMessage('Informe o nome do seu pet.');
      return;
    }

    setErrorMessage('');

    const messageLines = [
      `Olá! Gostaria de agendar na ${CLINIC_INFO.brandFull}.`,
      `Tutor: ${cleanTutor}`,
      `Pet: ${cleanPet} (${species})`,
      `Serviço: ${service}`,
      `Preferência de período: ${period}`,
      notes.trim() ? `Observações: ${notes.trim()}` : '',
    ].filter(Boolean);

    setSubmittedUrl(buildWhatsAppUrl(messageLines.join('\n')));
  };

  const handleReset = () => {
    setSubmittedUrl('');
    setErrorMessage('');
  };

  return (
    <section
      id="contato"
      className="border-t border-[hsl(var(--border-subtle))] bg-[hsl(var(--surface))] py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6 lg:px-8">
        <div className="grid items-start gap-12 lg:grid-cols-12 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <p className="mb-3 text-sm font-semibold text-[hsl(var(--secondary))]">
              Contato e localização
            </p>
            <h2 className="font-display text-[clamp(2rem,3.6vw,3rem)] font-semibold leading-[1.12] tracking-tight text-[hsl(var(--foreground))]">
              Prontos para receber você
            </h2>

            <div className="mt-8 rounded-2xl border border-[hsl(var(--secondary)/0.55)] bg-[hsl(var(--background))] p-6">
              <div className="flex items-start gap-3">
                <AlertTriangle
                  className="mt-0.5 h-5 w-5 shrink-0 text-[hsl(var(--secondary))]"
                  aria-hidden="true"
                />
                <div>
                  <h3 className="font-display text-lg font-semibold text-[hsl(var(--foreground))]">
                    Emergência veterinária
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-[hsl(var(--muted-foreground))]">
                    Seu pet precisa de ajuda urgente? Chame diretamente pelo
                    WhatsApp para orientação imediata com nossa equipe.
                  </p>
                  <a
                    href={emergencyHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-4 inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[hsl(var(--secondary-cta))] px-5 py-2.5 text-sm font-bold text-[hsl(var(--secondary-foreground))] whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[hsl(var(--secondary-cta-hover))]"
                  >
                    <MessageCircle
                      className="h-4 w-4 shrink-0"
                      aria-hidden="true"
                    />
                    <span>Atendimento de emergência</span>
                  </a>
                </div>
              </div>
            </div>

            <div className="mt-10 space-y-6 border-t border-[hsl(var(--border-subtle))] pt-8">
              <div className="flex items-start gap-3.5">
                <MapPin
                  className="mt-1 h-5 w-5 shrink-0 text-[hsl(var(--secondary))]"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs font-semibold text-[hsl(var(--muted-foreground))]">
                    Endereço
                  </p>
                  <p className="mt-1 text-base font-medium text-[hsl(var(--foreground))]">
                    {CLINIC_INFO.address}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <Phone
                  className="mt-1 h-5 w-5 shrink-0 text-[hsl(var(--secondary))]"
                  aria-hidden="true"
                />
                <div>
                  <p className="text-xs font-semibold text-[hsl(var(--muted-foreground))]">
                    Telefone e WhatsApp
                  </p>
                  <a
                    href={`tel:${CLINIC_INFO.phoneRaw}`}
                    className="mt-1 inline-block text-base font-semibold tabular-nums text-[hsl(var(--foreground))] transition-colors duration-150 hover:text-[hsl(var(--secondary))]"
                  >
                    {CLINIC_INFO.phoneFormatted}
                  </a>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            id="agendamento"
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="scroll-mt-24 rounded-3xl border border-[hsl(var(--border))] bg-[hsl(var(--background))] p-6 sm:p-10 lg:col-span-7"
          >
            <h3 className="font-display text-2xl font-semibold text-[hsl(var(--foreground))]">
              Agendamento Online
            </h3>
            <p className="mt-2 text-sm text-[hsl(var(--muted-foreground))]">
              Preencha os dados abaixo para enviar sua solicitação pronta no
              WhatsApp da clínica.
            </p>

            {submittedUrl ? (
              <div className="mt-8 rounded-2xl border border-[hsl(var(--secondary)/0.5)] bg-[hsl(var(--surface))] p-6">
                <div className="flex items-start gap-3">
                  <CheckCircle2
                    className="mt-0.5 h-6 w-6 shrink-0 text-[hsl(var(--secondary))]"
                    aria-hidden="true"
                  />
                  <div>
                    <h4 className="font-display text-xl font-semibold text-[hsl(var(--foreground))]">
                      Solicitação pronta para envio
                    </h4>
                    <p className="mt-2 text-sm leading-relaxed text-[hsl(var(--muted-foreground))]">
                      Resumo de <strong className="text-[hsl(var(--foreground))]">{petName}</strong> ({species}) —{' '}
                      {service}, período {period.toLowerCase()}. Clique abaixo para
                      concluir no WhatsApp.
                    </p>
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap items-center gap-4">
                  <a
                    href={submittedUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex min-h-[46px] items-center gap-2 rounded-xl bg-[hsl(var(--secondary-cta))] px-6 py-3 text-sm font-bold text-[hsl(var(--secondary-foreground))] whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[hsl(var(--secondary-cta-hover))]"
                  >
                    <MessageCircle
                      className="h-4 w-4 shrink-0"
                      aria-hidden="true"
                    />
                    <span>Conversar no WhatsApp</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleReset}
                    className="inline-flex min-h-[46px] items-center rounded-xl border border-[hsl(var(--border))] px-4 py-2.5 text-sm font-semibold text-[hsl(var(--muted-foreground))] whitespace-nowrap shrink-0 transition-colors duration-150 hover:text-[hsl(var(--foreground))]"
                  >
                    Editar dados
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate className="mt-8 space-y-5">
                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="tutor-name"
                      className="mb-2 block text-sm font-semibold text-[hsl(var(--foreground))]"
                    >
                      Seu nome
                    </label>
                    <input
                      id="tutor-name"
                      name="tutorName"
                      type="text"
                      required
                      value={tutorName}
                      onChange={(e) => setTutorName(e.target.value)}
                      placeholder="Ex.: Maria Oliveira"
                      className="min-h-[44px] w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--surface))] px-4 py-2.5 text-base text-[hsl(var(--foreground))] placeholder:text-[hsl(var(--muted-foreground)/0.6)] transition-colors duration-150 focus:border-[hsl(var(--secondary))] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="pet-name"
                      className="mb-2 block text-sm font-semibold text-[hsl(var(--foreground))]"
                    >
                      Nome do pet
                    </label>
                    <input
                      id="pet-name"
                      name="petName"
                      type="text"
                      required
                      value={petName}
                      onChange={(e) => setPetName(e.target.value)}
                      placeholder="Ex.: Thor"
                      className="min-h-[44px] w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--surface))] px-4 py-2.5 text-base text-[hsl(var(--foreground))] placeholder:text-[hsl(var(--muted-foreground)/0.6)] transition-colors duration-150 focus:border-[hsl(var(--secondary))] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid gap-5 sm:grid-cols-2">
                  <div>
                    <span className="mb-2 block text-sm font-semibold text-[hsl(var(--foreground))]">
                      Espécie
                    </span>
                    <div
                      role="group"
                      aria-label="Espécie do pet"
                      className="grid grid-cols-2 gap-1 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--surface))] p-1"
                    >
                      {(['Cão', 'Gato'] as const).map((option) => (
                        <button
                          key={option}
                          type="button"
                          onClick={() => setSpecies(option)}
                          className={`min-h-[38px] rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors duration-150 ${
                            species === option
                              ? 'bg-[hsl(var(--surface-brand))] text-[hsl(var(--primary-foreground))]'
                              : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]'
                          }`}
                        >
                          {option}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="service-select"
                      className="mb-2 block text-sm font-semibold text-[hsl(var(--foreground))]"
                    >
                      Serviço desejado
                    </label>
                    <select
                      id="service-select"
                      name="service"
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      className="min-h-[46px] w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--surface))] px-4 py-2.5 text-base text-[hsl(var(--foreground))] transition-colors duration-150 focus:border-[hsl(var(--secondary))] focus:outline-none"
                    >
                      {SERVICES.map((item) => (
                        <option key={item.id} value={item.title}>
                          {item.title}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <span className="mb-2 block text-sm font-semibold text-[hsl(var(--foreground))]">
                    Melhor período
                  </span>
                  <div
                    role="group"
                    aria-label="Período preferido"
                    className="grid grid-cols-3 gap-1 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--surface))] p-1"
                  >
                    {(['Manhã', 'Tarde', 'Flexível'] as const).map((option) => (
                      <button
                        key={option}
                        type="button"
                        onClick={() => setPeriod(option)}
                        className={`min-h-[38px] rounded-lg px-3 py-1.5 text-sm font-semibold transition-colors duration-150 ${
                          period === option
                            ? 'bg-[hsl(var(--surface-brand))] text-[hsl(var(--primary-foreground))]'
                            : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]'
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="booking-notes"
                    className="mb-2 block text-sm font-semibold text-[hsl(var(--foreground))]"
                  >
                    Observação rápida (opcional)
                  </label>
                  <textarea
                    id="booking-notes"
                    name="notes"
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Sintomas, idade do pet ou dúvida principal"
                    className="w-full rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--surface))] px-4 py-2.5 text-base text-[hsl(var(--foreground))] placeholder:text-[hsl(var(--muted-foreground)/0.6)] transition-colors duration-150 focus:border-[hsl(var(--secondary))] focus:outline-none"
                  />
                </div>

                {errorMessage && (
                  <p
                    role="alert"
                    className="text-sm font-semibold text-[hsl(var(--error))]"
                  >
                    {errorMessage}
                  </p>
                )}

                <div className="pt-2">
                  <button
                    type="submit"
                    className="inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[hsl(var(--secondary-cta))] px-6 py-3 text-base font-bold text-[hsl(var(--secondary-foreground))] transition-colors duration-150 hover:bg-[hsl(var(--secondary-cta-hover))] sm:w-auto"
                  >
                    <MessageCircle
                      className="h-5 w-5 shrink-0"
                      aria-hidden="true"
                    />
                    <span>Preparar agendamento no WhatsApp</span>
                  </button>
                </div>
              </form>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
