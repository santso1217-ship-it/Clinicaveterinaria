import { useState } from 'react';
import { HeartHandshake } from 'lucide-react';

interface ClinicImageProps {
  src: string;
  alt: string;
  className?: string;
  priority?: boolean;
}

export function ClinicImage({
  src,
  alt,
  className = '',
  priority = false,
}: ClinicImageProps) {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center gap-3 bg-gradient-to-br from-[hsl(var(--surface-brand))] to-[hsl(var(--surface))] p-6 text-center ${className}`}
      >
        <HeartHandshake
          className="h-10 w-10 text-[hsl(var(--secondary))]"
          aria-hidden="true"
        />
        <span className="font-display text-base font-medium text-[hsl(var(--foreground))]">
          {alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      loading={priority ? 'eager' : 'lazy'}
      decoding={priority ? 'sync' : 'async'}
      onError={() => setHasError(true)}
      className={className}
    />
  );
}
