import { ArrowDownRight, MessageCircle } from 'lucide-react';
import { buildWhatsAppUrl, HERO_IMAGE } from '../data/clinicData';
import { ClinicImage } from './ClinicImage';

export function HeroSection() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Gostaria de falar com a Animalmedic Clínica Veterinária.'
  );

  return (
    <section
      id="inicio"
      className="relative overflow-hidden bg-[hsl(var(--background))] pt-10 pb-20 sm:pt-14 sm:pb-24 lg:pt-16 lg:pb-28"
    >
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6 lg:px-8">
        <div className="grid items-stretch gap-10 lg:grid-cols-12 lg:gap-12">
          <div className="flex flex-col justify-center lg:col-span-6 lg:py-6">
            <p className="mb-4 text-sm font-semibold tracking-wide text-[hsl(var(--secondary))]">
              Animalmedic Clínica Veterinária · Guaratinguetá
            </p>

            <h1 className="font-display text-[clamp(2.5rem,4.9vw,4.35rem)] font-semibold leading-[1.06] tracking-tight text-[hsl(var(--foreground))]">
              Medicina veterinária com carinho e precisão.
            </h1>

            <p className="mt-6 max-w-xl text-base leading-[1.7] text-[hsl(var(--muted-foreground))] sm:text-lg">
              Cuidado completo para cães e gatos em consultas, vacinas, exames
              e cirurgias sem estresse.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-5">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-[48px] items-center gap-2.5 rounded-xl bg-[hsl(var(--secondary-cta))] px-6 py-3 text-base font-bold text-[hsl(var(--secondary-foreground))] whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[hsl(var(--secondary-cta-hover))]"
              >
                <MessageCircle className="h-5 w-5 shrink-0" aria-hidden="true" />
                <span>Conversar no WhatsApp</span>
              </a>

              <a
                href="#agendamento"
                className="inline-flex min-h-[48px] items-center gap-1.5 border-b border-[hsl(var(--border))] px-1 py-2 text-base font-semibold text-[hsl(var(--foreground))] whitespace-nowrap shrink-0 transition-colors duration-150 hover:border-[hsl(var(--secondary))] hover:text-[hsl(var(--secondary))]"
              >
                <span>Agendar online</span>
                <ArrowDownRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="relative h-full min-h-[280px] overflow-hidden rounded-[2rem] border border-[hsl(var(--border))] bg-[hsl(var(--surface))] sm:min-h-[380px] lg:min-h-[460px]">
              <ClinicImage
                src={HERO_IMAGE.src}
                alt={HERO_IMAGE.alt}
                priority
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
