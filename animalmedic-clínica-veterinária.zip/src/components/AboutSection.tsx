import { motion } from 'motion/react';
import { ArrowDown } from 'lucide-react';
import { TEAM_IMAGE } from '../data/clinicData';
import { ClinicImage } from './ClinicImage';

export function AboutSection() {
  return (
    <section
      id="sobre"
      className="bg-[hsl(var(--surface-brand))] py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-12 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="overflow-hidden rounded-t-[7rem] rounded-b-3xl border border-[hsl(var(--foreground)/0.16)] bg-[hsl(var(--surface))]">
              <div className="aspect-[4/3] w-full">
                <ClinicImage
                  src={TEAM_IMAGE.src}
                  alt={TEAM_IMAGE.alt}
                  className="h-full w-full object-cover"
                />
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <p className="mb-3 text-sm font-semibold text-[hsl(var(--secondary))]">
              Sobre a clínica
            </p>
            <h2 className="font-display text-[clamp(2rem,3.6vw,3rem)] font-semibold leading-[1.12] tracking-tight text-[hsl(var(--primary-foreground))]">
              Equipe dedicada ao bem-estar animal
            </h2>

            <p className="mt-6 text-base leading-[1.7] text-[hsl(var(--foreground)/0.9)] sm:text-lg">
              Na Animalmedic Clínica Veterinária, cada atendimento começa com
              escuta calma e respeito ao ritmo do seu pet. Recebemos cães e
              gatos em um ambiente acolhedor pensado para reduzir o estresse
              desde a chegada.
            </p>

            <p className="mt-4 text-base leading-[1.7] text-[hsl(var(--foreground)/0.82)]">
              Unimos olhar clínico atento, prevenção contínua e comunicação
              transparente com você para tomar sempre a melhor decisão pela
              saúde de quem faz parte da família.
            </p>

            <div className="mt-8 border-t border-[hsl(var(--foreground)/0.16)] pt-6 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-[hsl(var(--foreground)/0.85)]">
                <span>Cães e gatos</span>
                <span aria-hidden="true">·</span>
                <span>Vila Paraíba, Guaratinguetá</span>
              </div>

              <a
                href="#dicas"
                className="inline-flex items-center gap-2 text-sm font-bold text-[hsl(var(--secondary))] transition-opacity duration-150 hover:opacity-85"
              >
                <span>Ver dicas de cuidado</span>
                <ArrowDown className="h-4 w-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
