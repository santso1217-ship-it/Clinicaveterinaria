import { useState } from 'react';
import { motion } from 'motion/react';
import { ChevronDown } from 'lucide-react';
import { PET_TIPS } from '../data/clinicData';

export function TipsSection() {
  const [openTipId, setOpenTipId] = useState<string>(PET_TIPS[0].id);

  const toggleTip = (id: string) => {
    setOpenTipId((current) => (current === id ? '' : id));
  };

  return (
    <section
      id="dicas"
      className="bg-[hsl(var(--background))] py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-[820px] px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="text-center"
        >
          <p className="mb-3 text-sm font-semibold text-[hsl(var(--secondary))]">
            Dicas Pet
          </p>
          <h2 className="font-display text-[clamp(2rem,3.6vw,3rem)] font-semibold leading-[1.12] tracking-tight text-[hsl(var(--foreground))]">
            Dicas para uma vida longa
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base text-[hsl(var(--muted-foreground))]">
            Pequenos cuidados diários fazem toda a diferença no conforto e na
            prevenção de doenças.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
          className="mt-14 divide-y divide-[hsl(var(--border))] border-y border-[hsl(var(--border))]"
        >
          {PET_TIPS.map((tip, idx) => {
            const isOpen = openTipId === tip.id;
            const panelId = `tip-panel-${tip.id}`;
            return (
              <div key={tip.id} className="py-2">
                <button
                  type="button"
                  aria-expanded={isOpen}
                  aria-controls={panelId}
                  onClick={() => toggleTip(tip.id)}
                  className="flex min-h-[56px] w-full items-center justify-between gap-6 py-4 text-left transition-colors duration-150 hover:text-[hsl(var(--secondary))]"
                >
                  <span className="flex items-baseline gap-4">
                    <span className="font-display text-sm font-medium tabular-nums text-[hsl(var(--secondary))]">
                      0{idx + 1}
                    </span>
                    <span className="font-display text-lg font-medium text-[hsl(var(--foreground))] sm:text-xl">
                      {tip.title}
                    </span>
                  </span>

                  <ChevronDown
                    className={`h-5 w-5 shrink-0 text-[hsl(var(--muted-foreground))] transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-[hsl(var(--secondary))]' : ''
                    }`}
                    aria-hidden="true"
                  />
                </button>

                {isOpen && (
                  <motion.div
                    id={panelId}
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
                    className="pb-5 pl-9 pr-4 text-base leading-relaxed text-[hsl(var(--muted-foreground))]"
                  >
                    {tip.summary}
                  </motion.div>
                )}
              </div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
