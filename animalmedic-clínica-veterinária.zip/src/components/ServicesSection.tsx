import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { SERVICES, type ServiceItem } from '../data/clinicData';
import { ClinicImage } from './ClinicImage';

interface ServicesSectionProps {
  onSelectServiceForBooking: (serviceTitle: string) => void;
}

export function ServicesSection({
  onSelectServiceForBooking,
}: ServicesSectionProps) {
  const [activeService, setActiveService] = useState<ServiceItem>(SERVICES[0]);

  const handleBookClick = () => {
    onSelectServiceForBooking(activeService.title);
    const target = document.getElementById('agendamento');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <section
      id="servicos"
      className="border-t border-[hsl(var(--border-subtle))] bg-[hsl(var(--surface))] py-24 sm:py-28 lg:py-32"
    >
      <div className="mx-auto max-w-[1200px] px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="mb-14 max-w-2xl"
        >
          <p className="mb-3 text-sm font-semibold text-[hsl(var(--secondary))]">
            Serviços veterinários
          </p>
          <h2 className="font-display text-[clamp(2rem,3.6vw,3rem)] font-semibold leading-[1.12] tracking-tight text-[hsl(var(--foreground))]">
            Cuidado em cada fase da vida
          </h2>
        </motion.div>

        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-14">
          <div className="lg:col-span-5">
            <div
              role="tablist"
              aria-label="Lista de serviços veterinários"
              className="divide-y divide-[hsl(var(--border-subtle))] border-y border-[hsl(var(--border-subtle))]"
            >
              {SERVICES.map((service) => {
                const isSelected = service.id === activeService.id;
                return (
                  <button
                    key={service.id}
                    type="button"
                    role="tab"
                    aria-selected={isSelected}
                    onClick={() => setActiveService(service)}
                    className={`group flex w-full items-center justify-between gap-4 py-5 text-left transition-colors duration-150 ${
                      isSelected
                        ? 'text-[hsl(var(--foreground))]'
                        : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--foreground))]'
                    }`}
                  >
                    <span className="flex items-baseline gap-4">
                      <span
                        className={`font-display text-sm font-medium tabular-nums transition-colors duration-150 ${
                          isSelected
                            ? 'text-[hsl(var(--secondary))]'
                            : 'text-[hsl(var(--muted-foreground))]'
                        }`}
                      >
                        {service.index}.
                      </span>
                      <span className="font-display text-xl font-medium sm:text-2xl">
                        {service.title}
                      </span>
                    </span>

                    <ArrowRight
                      className={`h-5 w-5 shrink-0 transition-transform duration-150 ${
                        isSelected
                          ? 'translate-x-0 text-[hsl(var(--secondary))]'
                          : '-translate-x-1 opacity-0 group-hover:translate-x-0 group-hover:opacity-60'
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeService.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                className="overflow-hidden rounded-3xl border border-[hsl(var(--border))] bg-[hsl(var(--background))]"
              >
                <div className="aspect-[4/3] w-full overflow-hidden">
                  <ClinicImage
                    src={activeService.imageSrc}
                    alt={activeService.imageAlt}
                    className="h-full w-full object-cover"
                  />
                </div>

                <div className="flex flex-col justify-between gap-6 p-6 sm:flex-row sm:items-end sm:p-8">
                  <div className="max-w-md">
                    <h3 className="font-display text-2xl font-semibold text-[hsl(var(--foreground))]">
                      {activeService.title}
                    </h3>
                    <p className="mt-2 text-base leading-relaxed text-[hsl(var(--muted-foreground))]">
                      {activeService.summary}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleBookClick}
                    className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[hsl(var(--secondary-cta))] px-5 py-2.5 text-sm font-bold text-[hsl(var(--secondary-foreground))] whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[hsl(var(--secondary-cta-hover))]"
                  >
                    <span>Agendar este serviço</span>
                    <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
