import { useState } from 'react';
import { Menu, MessageCircle, X } from 'lucide-react';
import { buildWhatsAppUrl, CLINIC_INFO } from '../data/clinicData';

const NAV_LINKS = [
  { href: '#inicio', label: 'Início' },
  { href: '#servicos', label: 'Serviços' },
  { href: '#sobre', label: 'Sobre' },
  { href: '#dicas', label: 'Dicas' },
  { href: '#contato', label: 'Contato' },
] as const;

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const whatsappHref = buildWhatsAppUrl();

  return (
    <header className="sticky top-0 z-40 border-b border-[hsl(var(--border-subtle))] bg-[hsl(var(--background)/0.92)] backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[1200px] items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        <a
          href="#inicio"
          className="font-display text-xl font-semibold tracking-tight text-[hsl(var(--foreground))] whitespace-nowrap shrink-0 transition-opacity duration-150 hover:opacity-90"
        >
          {CLINIC_INFO.brandShort}
        </a>

        <nav
          aria-label="Navegação principal"
          className="hidden md:flex items-center gap-7 text-sm font-semibold text-[hsl(var(--muted-foreground))]"
        >
          {NAV_LINKS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="whitespace-nowrap shrink-0 border-b border-transparent py-1 transition-colors duration-150 hover:border-[hsl(var(--secondary))] hover:text-[hsl(var(--foreground))]"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center gap-2 rounded-xl bg-[hsl(var(--secondary-cta))] px-4 py-2 text-sm font-bold text-[hsl(var(--secondary-foreground))] whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-[hsl(var(--secondary-cta-hover))]"
          >
            <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
            <span>Conversar no WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-expanded={menuOpen}
            aria-controls="mobile-nav"
            aria-label={menuOpen ? 'Fechar menu' : 'Abrir menu'}
            className="inline-flex h-11 w-11 items-center justify-center rounded-xl border border-[hsl(var(--border))] text-[hsl(var(--foreground))] transition-colors duration-150 hover:bg-[hsl(var(--surface))] md:hidden"
          >
            {menuOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {menuOpen && (
        <nav
          id="mobile-nav"
          aria-label="Navegação móvel"
          className="border-t border-[hsl(var(--border-subtle))] bg-[hsl(var(--surface))] px-4 py-4 md:hidden"
        >
          <div className="flex flex-col gap-1">
            {NAV_LINKS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMenuOpen(false)}
                className="flex min-h-[44px] items-center rounded-lg px-3 text-base font-semibold text-[hsl(var(--foreground))] transition-colors duration-150 hover:bg-[hsl(var(--surface-elevated))]"
              >
                {item.label}
              </a>
            ))}
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMenuOpen(false)}
              className="mt-3 inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[hsl(var(--secondary-cta))] px-5 py-2.5 text-sm font-bold text-[hsl(var(--secondary-foreground))] transition-colors duration-150 hover:bg-[hsl(var(--secondary-cta-hover))]"
            >
              <MessageCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
              <span>Conversar no WhatsApp</span>
            </a>
          </div>
        </nav>
      )}
    </header>
  );
}
