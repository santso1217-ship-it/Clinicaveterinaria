/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { MotionConfig } from 'motion/react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { AboutSection } from './components/AboutSection';
import { TipsSection } from './components/TipsSection';
import { ContactBookingSection } from './components/ContactBookingSection';
import { Footer } from './components/Footer';
import { SERVICES } from './data/clinicData';

export default function App() {
  const [selectedService, setSelectedService] = useState<string>(
    SERVICES[3].title
  );

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[hsl(var(--background))] text-[hsl(var(--foreground))]">
        <Header />
        <main>
          <HeroSection />
          <ServicesSection onSelectServiceForBooking={setSelectedService} />
          <AboutSection />
          <TipsSection />
          <ContactBookingSection preselectedService={selectedService} />
        </main>
        <Footer />
      </div>
    </MotionConfig>
  );
}
