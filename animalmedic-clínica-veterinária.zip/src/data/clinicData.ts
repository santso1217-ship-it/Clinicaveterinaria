export interface ServiceItem {
  id: string;
  index: string;
  title: string;
  summary: string;
  imageSrc: string;
  imageAlt: string;
}

export interface PetTipItem {
  id: string;
  title: string;
  summary: string;
}

export const CLINIC_INFO = {
  brandShort: 'Animalmedic',
  brandFull: 'Animalmedic Clínica Veterinária',
  address: 'Av. Carlos Rebelo Júnior, 297 - Vila Paraiba, Guaratinguetá - SP, 12515-300',
  phoneRaw: '012997353799',
  phoneFormatted: '(12) 99735-3799',
  whatsappNumber: '5512997353799',
} as const;

export function buildWhatsAppUrl(customMessage?: string): string {
  const defaultMsg =
    'Olá! Gostaria de conversar com a equipe da Animalmedic Clínica Veterinária.';
  const text = encodeURIComponent(customMessage || defaultMsg);
  return `https://wa.me/${CLINIC_INFO.whatsappNumber}?text=${text}`;
}

export const HERO_IMAGE = {
  src: '/src/assets/images/hero_vet_happy_pet_1794923001834.jpg',
  alt: 'Médica veterinária examinando um cão golden retriever feliz em consultório iluminado da Animalmedic',
};

export const TEAM_IMAGE = {
  src: '/src/assets/images/about_vet_team_1794923005014.jpg',
  alt: 'Equipe veterinária dedicada da Animalmedic com um cão e um gato em ambiente acolhedor',
};

export const SERVICES: ServiceItem[] = [
  {
    id: 'cirurgia',
    index: '01',
    title: 'Cirurgia Segura',
    summary:
      'Centro cirúrgico equipado com monitoramento contínuo e acompanhamento atento em todo o pós-operatório.',
    imageSrc: '/src/assets/images/service_surgery_care_1794923002717.jpg',
    imageAlt: 'Médica veterinária monitorando cão em centro cirúrgico equipado e seguro',
  },
  {
    id: 'vacinas',
    index: '02',
    title: 'Vacinação Atualizada',
    summary:
      'Protocolos individuais para filhotes e adultos com aplicação tranquila e carteira sempre em dia.',
    imageSrc: '/src/assets/images/service_vaccine_checkup_1794923002764.jpg',
    imageAlt: 'Veterinário sorrindo enquanto aplica vacina com carinho em cachorro tranquilo',
  },
  {
    id: 'exames',
    index: '03',
    title: 'Exames Diagnósticos',
    summary:
      'Avaliações laboratoriais e de imagem com precisão para cuidar da saúde antes mesmo dos sintomas.',
    imageSrc: '/src/assets/images/service_diagnostic_exams_1794923003946.jpg',
    imageAlt: 'Veterinária realizando exame de ultrassom cuidadoso em gato tranquilo',
  },
  {
    id: 'consulta',
    index: '04',
    title: 'Clínica Geral',
    summary:
      'Consultas sem pressa para ouvir você, examinar cada detalhe e orientar o melhor cuidado diário.',
    imageSrc: '/src/assets/images/hero_vet_happy_pet_1794923001834.jpg',
    imageAlt: 'Consulta clínica veterinária acolhedora com cão feliz na Animalmedic',
  },
];

export const PET_TIPS: PetTipItem[] = [
  {
    id: 'vacinacao',
    title: 'Mantenha o calendário vacinal em dia',
    summary:
      'O reforço anual protege cães e gatos contra doenças silenciosas e graves. Mesmo pets que vivem em apartamentos precisam dessa barreira preventiva.',
  },
  {
    id: 'hidratacao',
    title: 'Observe a hidratação ao longo do dia',
    summary:
      'Água fresca em mais de um ponto da casa estimula o consumo, principalmente para gatos. Mudanças bruscas na sede merecem uma avaliação clínica.',
  },
  {
    id: 'sinais',
    title: 'Reconheça sinais sutis de desconforto',
    summary:
      'Falta de apetite, apatia ou isolamento repentino costumam ser os primeiros avisos de dor ou febre. Quanto antes examinarmos, mais leve é a recuperação.',
  },
  {
    id: 'checkup',
    title: 'Check-up preventivo prolonga a vitalidade',
    summary:
      'Exames de rotina identificam alterações renais, cardíacas ou dentárias no início, garantindo mais conforto e qualidade de vida em todas as idades.',
  },
];
